#ifndef ROUTER_TABLE_H_
#define ROUTER_TABLE_H_

void fill_routing_table(char *payload);
void routing_table_response(int sockfd);

#endif
