#ifndef UPDATE_H_
#define UPDATE_H_


bool update(char *payload);
void update_response(int sockfd, char *payload);

#endif
