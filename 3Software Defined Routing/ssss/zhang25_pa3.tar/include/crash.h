#ifndef CRASH_H_
#define CRASH_H_

void crash_response(int sockfd);

#endif
