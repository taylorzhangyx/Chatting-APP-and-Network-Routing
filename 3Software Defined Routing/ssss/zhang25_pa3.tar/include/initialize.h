#ifndef INITIALIZE_H_
#define INITIALIZE_H_

void init_response(int sock_index, char *payload);
bool init_router(char *payload);
void print_info();
void initial();

#endif
