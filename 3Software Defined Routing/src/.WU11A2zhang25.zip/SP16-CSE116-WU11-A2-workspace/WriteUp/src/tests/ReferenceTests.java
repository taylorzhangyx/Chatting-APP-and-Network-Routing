package tests;

import static org.junit.Assert.*;

import java.util.Random;

import org.junit.Before;
import org.junit.Test;

public class ReferenceTests {

	private code.WriteUp wu;
	
	@Before
	public void setup() {
		wu = new code.WriteUp();
	}
	
	@Test public void test00() { genericTestCode(randomTestCase()); }
	@Test public void test01() { genericTestCode(randomTestCase()); }
	@Test public void test02() { genericTestCode(randomTestCase()); }
	@Test public void test03() { genericTestCode(randomTestCase()); }
	@Test public void test04() { genericTestCode(randomTestCase()); }
	@Test public void test05() { genericTestCode(randomTestCase()); }
	@Test public void test06() { genericTestCode(randomTestCase()); }
	@Test public void test07() { genericTestCode(randomTestCase()); }
	@Test public void test08() { genericTestCode(randomTestCase()); }
	@Test public void test09() { genericTestCode(randomTestCase()); }

	private void genericTestCode(Pair<String, String> p) {
		String input = p.a;
		String expected = p.b;
		String actual = wu.solution(input);
		assertTrue("I expected solution(\""+input+"\") to return \""+expected+"\", but it returned "+format(actual)+".",
				expected.equals(actual));
	}
	
	// double characters from b
	private Pair<String,String> randomTestCase() {
		String a = "abcdefghijklmnopqrstuvwxyz";
		String b = ".,!?:;";
		StringBuffer input = new StringBuffer();
		StringBuffer expected = new StringBuffer();
		Random rand = new Random();
		int howMany = rand.nextInt(10);
		for (int i=0; i<howMany; i=i+1) {
			if (rand.nextBoolean()) {
				char ch = a.charAt(rand.nextInt(a.length()));
				input.append(ch);
				expected.append(ch);
			}
			else {
				char ch = b.charAt(rand.nextInt(b.length()));
				input.append(ch);
				expected.append(ch);
				expected.append(ch);
			}			
		}
		return new Pair<String,String>(input.toString(), expected.toString());
	}

	private String format(String actual) {
		if (actual == null) {
			return "null";
		}
		return "\""+actual+"\"";
	}

	private class Pair<A,B> {
		public A a;
		public B b;
		public Pair(A a, B b) {
			this.a = a; this.b = b;
		}
	}

}
